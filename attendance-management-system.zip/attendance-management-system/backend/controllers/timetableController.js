const supabase = require("../config/supabase");

// ====================================
// GET CURRENT CLASS
// GET /api/timetable/current
// ====================================

const getCurrentClass = async (req, res) => {
  try {
    const now = new Date();

    // Sunday = 0, Monday = 1...
    let day = now.getDay();

    // Convert Sunday(0) -> 7
    if (day === 0) day = 7;

    // Current Time (HH:MM:SS)
    const currentTime = now.toLocaleTimeString("en-GB", {
      hour12: false,
    });

    const { data, error } = await supabase
      .from("Timetable")
      .select("*")
      .eq("day_of_week", day)
      .lte("start_time", currentTime)
      .gte("end_time", currentTime)
      .single();

    if (error || !data) {
      return res.status(200).json({
        success: false,
        message: "No active class at this time.",
      });
    }

    return res.status(200).json({
      success: true,
      currentClass: data,
    });

  } catch (err) {
    return res.status(500).json({
      success: false,
      error: err.message,
    });
  }
};

module.exports = {
  getCurrentClass,
};